import React from 'react';
import { BarChart3, TrendingDown, TrendingUp, Calendar, Target } from 'lucide-react';
import { Activity, CarbonGoal } from '../types';

interface DashboardProps {
  activities: Activity[];
  goals: CarbonGoal[];
}

const Dashboard: React.FC<DashboardProps> = ({ activities, goals }) => {
  // Calculate metrics
  const totalEmissions = activities.reduce((sum, activity) => sum + activity.carbonFootprint, 0);
  const thisMonthEmissions = activities
    .filter(activity => {
      const activityDate = new Date(activity.date);
      const now = new Date();
      return activityDate.getMonth() === now.getMonth() && 
             activityDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, activity) => sum + activity.carbonFootprint, 0);

  // Group activities by type
  const emissionsByType = activities.reduce((acc, activity) => {
    acc[activity.type] = (acc[activity.type] || 0) + activity.carbonFootprint;
    return acc;
  }, {} as Record<string, number>);

  const currentGoal = goals.find(goal => goal.type === 'monthly');
  const goalProgress = currentGoal ? (thisMonthEmissions / currentGoal.target) * 100 : 0;

  return (
    <div className="space-y-8">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Emissions</p>
              <p className="text-3xl font-bold text-gray-900">{totalEmissions.toFixed(1)}</p>
              <p className="text-sm text-gray-500">kg CO₂</p>
            </div>
            <div className="bg-red-100 p-3 rounded-lg">
              <BarChart3 className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">This Month</p>
              <p className="text-3xl font-bold text-gray-900">{thisMonthEmissions.toFixed(1)}</p>
              <p className="text-sm text-gray-500">kg CO₂</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Goal Progress</p>
              <p className="text-3xl font-bold text-gray-900">{goalProgress.toFixed(0)}%</p>
              <p className="text-sm text-gray-500">of monthly target</p>
            </div>
            <div className={`p-3 rounded-lg ${goalProgress > 100 ? 'bg-red-100' : 'bg-green-100'}`}>
              <Target className={`h-6 w-6 ${goalProgress > 100 ? 'text-red-600' : 'text-green-600'}`} />
            </div>
          </div>
        </div>
      </div>

      {/* Emissions by Category */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Emissions by Category</h3>
        <div className="space-y-4">
          {Object.entries(emissionsByType).map(([type, emissions]) => {
            const percentage = totalEmissions > 0 ? (emissions / totalEmissions) * 100 : 0;
            return (
              <div key={type} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-gradient-to-r from-green-400 to-blue-500"></div>
                  <span className="text-sm font-medium text-gray-700 capitalize">{type.replace('-', ' ')}</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-16 text-right">
                    {emissions.toFixed(1)} kg
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Recent Activities</h3>
        {activities.length === 0 ? (
          <div className="text-center py-8">
            <BarChart3 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No activities recorded yet</p>
            <p className="text-sm text-gray-400">Start tracking your carbon footprint by adding your first activity</p>
          </div>
        ) : (
          <div className="space-y-3">
            {activities.slice(-5).reverse().map((activity) => (
              <div key={activity.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{activity.description}</p>
                  <p className="text-sm text-gray-500">
                    {activity.amount} {activity.unit} • {activity.date}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">{activity.carbonFootprint.toFixed(1)} kg CO₂</p>
                  <p className="text-sm text-gray-500 capitalize">{activity.type}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Monthly Goal Progress */}
      {currentGoal && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Monthly Goal Progress</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-600">Progress</span>
              <span className="text-sm font-medium text-gray-900">
                {thisMonthEmissions.toFixed(1)} / {currentGoal.target} kg CO₂
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className={`h-3 rounded-full transition-all duration-300 ${
                  goalProgress > 100 ? 'bg-red-500' : 'bg-green-500'
                }`}
                style={{ width: `${Math.min(goalProgress, 100)}%` }}
              ></div>
            </div>
            <div className="flex items-center space-x-2">
              {goalProgress > 100 ? (
                <>
                  <TrendingUp className="h-4 w-4 text-red-500" />
                  <span className="text-sm text-red-600">
                    {(goalProgress - 100).toFixed(0)}% over target
                  </span>
                </>
              ) : (
                <>
                  <TrendingDown className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-600">
                    {(100 - goalProgress).toFixed(0)}% remaining
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;