import React, { useState } from 'react';
import { Plus, Save } from 'lucide-react';
import { Activity, ACTIVITY_TYPES } from '../types';

interface ActivityFormProps {
  onAddActivity: (activity: Omit<Activity, 'id' | 'date'>) => void;
}

const ActivityForm: React.FC<ActivityFormProps> = ({ onAddActivity }) => {
  const [activityType, setActivityType] = useState<keyof typeof ACTIVITY_TYPES>('transportation');
  const [subType, setSubType] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [customFactor, setCustomFactor] = useState('');

  const currentActivityType = ACTIVITY_TYPES[activityType];
  const availableSubTypes = Object.entries(currentActivityType.factors);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!subType || !description || !amount) {
      alert('Please fill in all required fields');
      return;
    }

    const selectedFactor = currentActivityType.factors[subType as keyof typeof currentActivityType.factors];
    const carbonFactor = subType === 'custom' && customFactor ? 
      parseFloat(customFactor) : selectedFactor.factor;
    
    const carbonFootprint = parseFloat(amount) * carbonFactor;

    const newActivity: Omit<Activity, 'id' | 'date'> = {
      type: activityType,
      description,
      amount: parseFloat(amount),
      unit: selectedFactor.unit,
      carbonFootprint
    };

    onAddActivity(newActivity);

    // Reset form
    setDescription('');
    setAmount('');
    setCustomFactor('');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
        <div className="flex items-center space-x-3 mb-8">
          <div className="bg-green-500 p-2 rounded-lg">
            <Plus className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Add New Activity</h2>
            <p className="text-gray-600">Track your carbon footprint by recording daily activities</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Activity Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Activity Category
            </label>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {Object.entries(ACTIVITY_TYPES).map(([key, type]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setActivityType(key as keyof typeof ACTIVITY_TYPES);
                    setSubType('');
                  }}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    activityType === key
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-600'
                  }`}
                >
                  <div className="text-center">
                    <div className="text-sm font-medium">{type.label}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Sub-type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Specific Activity
            </label>
            <select
              value={subType}
              onChange={(e) => setSubType(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            >
              <option value="">Select an activity...</option>
              {availableSubTypes.map(([key, factor]) => (
                <option key={key} value={key}>
                  {factor.label} (per {factor.unit})
                </option>
              ))}
            </select>
          </div>

          {/* Custom Factor for Other Category */}
          {activityType === 'other' && subType === 'custom' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Carbon Factor (kg CO₂ per unit)
              </label>
              <input
                type="number"
                step="0.01"
                value={customFactor}
                onChange={(e) => setCustomFactor(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter carbon emission factor"
                required
              />
            </div>
          )}

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Describe your activity..."
              required
            />
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Amount 
              {subType && availableSubTypes.find(([key]) => key === subType) && (
                <span className="text-gray-500">
                  ({availableSubTypes.find(([key]) => key === subType)?.[1].unit})
                </span>
              )}
            </label>
            <input
              type="number"
              step="0.1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Enter amount..."
              required
            />
          </div>

          {/* Carbon Footprint Preview */}
          {subType && amount && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-800">
                  Estimated Carbon Footprint:
                </span>
                <span className="text-lg font-bold text-green-900">
                  {(() => {
                    const selectedFactor = currentActivityType.factors[subType as keyof typeof currentActivityType.factors];
                    const carbonFactor = subType === 'custom' && customFactor ? 
                      parseFloat(customFactor) : selectedFactor.factor;
                    return (parseFloat(amount) * carbonFactor).toFixed(2);
                  })()} kg CO₂
                </span>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
          >
            <Save className="h-5 w-5" />
            <span>Add Activity</span>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ActivityForm;